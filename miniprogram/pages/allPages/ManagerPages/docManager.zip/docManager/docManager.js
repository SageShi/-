Page({

  /**
   * 页面的初始数据
   */
  data: {
    leftLists: [
      "视频", "文档", "重要通知"
    ],
    indexId: 0,
    searchWord: "",
    searchWord1: "",
    //是否弹出弹窗
    showModal: false,
    videoVid:'',
    videoName:'',
    uploadFileName:'',
  },
  // 左侧点击事件
  jumpIndex(e) {
    let index = e.currentTarget.dataset.menuindex
    let that = this
    that.setData({
      indexId: index
    });
    this.refresh()
  },

  refresh:function()
  {
    const db = wx.cloud.database({});
    db.collection('videos').get({
      success: res => {
        this.setData({
          videoList: res.data
        })
      }
    })

    db.collection('fileID').get({
      success: res => {
        this.setData({
          fileIDList: res.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  clickVideo: function (e) {
    var vid = e.currentTarget.dataset.vid;
    var id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '/pages/allPages/videoPlay/videoPlay?vid=' + vid + '&id' + id
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.refresh()
  },

  searchInput: function (e) {
    this.setData({ searchWord: e.detail.value })
  },

  //关键字搜索
  searchNotice: function (e) {
    const db = wx.cloud.database({});
    // 数据库正则对象（正则表达式查询）
    db.collection('videos').where({
      name: db.RegExp({
        regexp: this.data.searchWord,
        options: 'i',
      })
    }).get({
      success: res => {
        this.setData({
          videoList: res.data
        })
        console.log(res.data)
      },
      fail: function (res) {
        console.log("not found")
      }
    })
  },


  searchInput1: function (e) {
    this.setData({ searchWord1: e.detail.value })
  },

  //关键字搜索
  searchNotice1: function (e) {
    const db = wx.cloud.database({});
    // 数据库正则对象（正则表达式查询）
    db.collection('fileID').where({
      fileid: db.RegExp({
        regexp: this.data.searchWord1,
        options: 'i',
      })
    }).get({
      success: res => {
        this.setData({
          fileIDList: res.data
        })
      },
      fail: function (res) {
        console.log("not found")
      }
    })
  },

  clickDoc: function (e) {
    /*var src = e.currentTarget.dataset.vedio // e.currentTarget
    wx.navigateTo({
      url: '../video/video?src='+src
    })*/
    wx.showLoading({
      title: '加载中',
    })
    wx.cloud.downloadFile({
      fileID: 'cloud://xiaochengxu-o6nj9.7869-xiaochengxu-o6nj9-1259225399/' + e.currentTarget.dataset.fileid,
      success: res => {
        // 返回临时文件路径
        console.log(res.tempFilePath),
          wx.openDocument({
            filePath: res.tempFilePath,
            success: function (res) {
              wx.hideLoading()
            }
          })
      }
    })
  },
  
  videoUpload:function(e)
  {
    this.setData({
      showModal: true
    })
  }, 
  /**
    * 弹出框蒙层截断touchmove事件
    */
  preventTouchMove: function () {
  },
  /**
   * 隐藏模态对话框
   */
  hideModal: function () {
    this.setData({
      showModal: false
    });
  },
  /**
   * 对话框取消按钮点击事件
   */
  onCancel: function () {
    this.hideModal();
  },
  /**
   * 对话框确认按钮点击事件
   */
  onConfirm: function () {
    const db = wx.cloud.database()
    db.collection('videos').add({
      data: {
        vid:this.data.videoVid,
        name: this.data.videoName
      },
      success: res => {
        wx.showToast({
          title: '上传成功',
        })
        this.resetData()
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '上传失败'
        })
      }
    })

    this.hideModal();

    this.refresh()
  },

  inputVid:function(e){
    this.data.videoVid = e.detail.value
  },
  inputName:function(e){
    this.data.videoName = e.detail.value
  },

  fileUpload: function (e) {
      var that = this;
      wx.chooseMessageFile({
        count: 1,
        type: 'file',
        success(res) {
          var filename = res.tempFiles[0].name
          console.info(filename);
          that.setData({ uploadFileName: filename });

          wx.cloud.uploadFile({
            cloudPath: filename,
            filePath: res.tempFiles[0].path, // 文件路径
            success: res => {
              const db = wx.cloud.database()
              db.collection('fileID').add({
                data: {
                  fileid: that.data.uploadFileName
                },
                success: res => {
                  that.refresh()
                }
              })
              wx.showToast({
                title: '上传成功',
              })
              
            },
            fail: err => {
              wx.showToast({
                icon: 'none',
                title: '上传失败'
              })
              console.log(filename)
            }
          })
          }
          })
  }, 

  deleteVideo:function(e)
  {
    
  },
  deleteFile:function(e)
  {

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})